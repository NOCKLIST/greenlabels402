Memory-Game
===========

AngularJS example app that implements the famous memory game of finding matching pairs of cards.  Popular with toddlers everywhere!