'use strict';
/* App Controllers */


var memoryGameApp = angular.module('memoryGameApp', []);


memoryGameApp.factory('game', function() {
  var tileNames = ['Washington-OG-Kush', 'CHRONIC-CANNIBAL-INDICA', 'CHEERLEADER-COOKIES', 'SEATTLE-PURPS-INDICA', 'HAIR-OF-THE-ABSTRACT-SATIVA', 'HARLEQUIN-BLACK-SATIVA',
    'LARRY-OG-KUSH', 'MS-VALDEZ-SATIVA'];

  return new Game(tileNames);
});


memoryGameApp.controller('GameCtrl', function GameCtrl($scope, game) {
  $scope.game = game;
});
